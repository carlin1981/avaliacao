package Test;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

// Classe de suíte que agrupa todos os testes
@RunWith(Suite.class)
@Suite.SuiteClasses({
        GerenciadorContatosTest.class // Adicione outras classes de teste aqui, se houver
})
public class Alltests {
    // Essa classe permanece vazia, pois é apenas um contêiner para a execução dos testes
}
