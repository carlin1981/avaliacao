package Test;

import org.junit.Before;
import org.junit.Test;

import modelo.Contato;
import modelo.GerenciadorContatos;

import static org.junit.Assert.*;

public class GerenciadorContatosTest {
    private GerenciadorContatos gerenciador;

    @Before
    public void setUp() {
        gerenciador = new GerenciadorContatos(); // Inicializa o gerenciador antes de cada teste
    }

    @Test
    //@author Carlos Alexandre e Thalles Nascimento
	 //* @date 27/09/2024
    /*======== Fase 1: Montagem do Cenário ========*/
	//criando alguns clientes
    public void testAdicionarContato() {
        Contato contato = new Contato();
        contato.setNome("João");
        contato.setEmail("joao@example.com");
        contato.setEndereco("Rua A, 123");

        gerenciador.adicionarContato(contato);

        // Verificando se o contato foi adicionado corretamente
        assertEquals(1, gerenciador.getContatos().size());
        assertEquals("João", gerenciador.getContatos().get(0).getNome());
        assertEquals(new Long(1), gerenciador.getContatos().get(0).getId()); // ID deve ser 1
    }

    @Test
    //@author Carlos Alexandre e Thalles Nascimento
	 //* @date 27/09/2024
    //Teste da remoção de um cliente a partir do seu ID
    
    public void testRemoverContato() {
        Contato contato = new Contato();
        contato.setNome("Maria");
        contato.setEmail("maria@example.com");
        contato.setEndereco("Rua B, 456");
        gerenciador.adicionarContato(contato);
   
        Long idRemover = contato.getId();
        gerenciador.removerContato(idRemover);

    	/*======== Fase 2: Execução do Teste ========*/
      
        assertEquals(0, gerenciador.getContatos().size());
    }

    @Test
    //@author Carlos Alexandre e Thalles Nascimento
	 //* @date 27/09/2024
    public void testPesquisarContatoPorId() {
        Contato contato = new Contato();
        contato.setNome("Carlos");
        contato.setEmail("carlos@example.com");  
        contato.setEndereco("Rua C, 789");
        gerenciador.adicionarContato(contato);

        Contato encontrado = gerenciador.pesquisarContatoPorId(contato.getId());

        // Verifica se o contato foi encontrado corretamente
        assertNotNull(encontrado);
        assertEquals("Carlos", encontrado.getNome());
    }

    @Test
    
    public void testPesquisarContatoInexistente() {
        Contato contato = new Contato();
        contato.setNome("Ana");
        contato.setEmail("ana@example.com");
        contato.setEndereco("Rua D, 101");
        gerenciador.adicionarContato(contato);

        // Pesquisa um ID inexistente
        Contato encontrado = gerenciador.pesquisarContatoPorId(999L);
        
        // Verifica se o resultado é null
        assertNull(encontrado);
    }

    @Test
    public void testReutilizarId() {
        Contato contato1 = new Contato();
        contato1.setNome("Lucas");
        contato1.setEmail("lucas@example.com");
        contato1.setEndereco("Rua E, 202");
        gerenciador.adicionarContato(contato1);

        Long idRemover = contato1.getId();
        gerenciador.removerContato(idRemover); // Remove contato

        Contato contato2 = new Contato();
        contato2.setNome("Fernanda");
        contato2.setEmail("fernanda@example.com");
        contato2.setEndereco("Rua F, 303");
        gerenciador.adicionarContato(contato2); // Adiciona novo contato

        // Verifica se o novo contato reutiliza o ID do contato removido
        assertEquals(new Long(1), contato2.getId()); // ID deve ser 1
    }
}
