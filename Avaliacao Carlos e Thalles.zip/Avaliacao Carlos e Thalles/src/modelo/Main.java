package modelo;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        GerenciadorContatos gerenciador = new GerenciadorContatos(); // Cria uma instância do gerenciador de contatos
        Scanner scanner = new Scanner(System.in);
        int opcao = -1; // Inicializa a opção para entrar no loop

        do {
            System.out.println("\nGerenciador de Contatos");
            System.out.println("1. Adicionar Contato");
            System.out.println("2. Remover Contato");
            System.out.println("3. Pesquisar Contato por ID");
            System.out.println("0. Sair");
            System.out.print("Escolha uma opção: ");

            try {
                opcao = scanner.nextInt(); // Lê a opção do usuário
                scanner.nextLine(); // Consumir a nova linha

                switch (opcao) {
                    case 1:
                        // Adicionar Contato
                        Contato novoContato = new Contato();
                        System.out.print("Nome: ");
                        novoContato.setNome(scanner.nextLine());
                        System.out.print("Email: ");
                        novoContato.setEmail(scanner.nextLine());
                        System.out.print("Endereço: ");
                        novoContato.setEndereco(scanner.nextLine());
                        gerenciador.adicionarContato(novoContato); // Adiciona o contato usando o gerenciador
                        System.out.println("Contato adicionado com sucesso! ID: " + novoContato.getId());
                        break;
                    case 2:
                        // Remover Contato
                        if (gerenciador.getContatos().isEmpty()) {
                            System.out.println("Nenhum contato disponível para remover.");
                        } else {
                            System.out.println("Lista de Contatos:");
                            gerenciador.getContatos().forEach(contato -> 
                                System.out.println("ID: " + contato.getId() + ", Nome: " + contato.getNome())
                            );
                            System.out.print("ID do contato a ser removido: ");
                            Long idRemover = scanner.nextLong();
                            gerenciador.removerContato(idRemover); // Remove o contato usando o gerenciador
                        }
                        break;
                    case 3:
                        // Pesquisar Contato
                        System.out.print("ID do contato a ser pesquisado: ");
                        Long idPesquisar = scanner.nextLong();
                        Contato contatoEncontrado = gerenciador.pesquisarContatoPorId(idPesquisar); // Pesquisa o contato usando o gerenciador
                        if (contatoEncontrado != null) {
                            // Exibe todas as informações do contato encontrado
                            System.out.println("Contato encontrado:");
                            System.out.println("ID: " + contatoEncontrado.getId());
                            System.out.println("Nome: " + contatoEncontrado.getNome());
                            System.out.println("Email: " + contatoEncontrado.getEmail());
                            System.out.println("Endereço: " + contatoEncontrado.getEndereco());
                        } else {
                            System.out.println("Contato não encontrado. Verifique se o ID está correto.");
                        }
                        System.out.println("Pressione Enter para continuar...");
                        scanner.nextLine(); // Aguarda o usuário pressionar Enter
                        break;
                    case 0:
                        // Sair
                        System.out.println("Saindo...");
                        break;
                    default:
                        System.out.println("Opção inválida, tente novamente.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Entrada inválida. Por favor, insira um número.");
                scanner.nextLine(); // Limpa a entrada inválida
            } catch (Exception e) {
                System.out.println("Ocorreu um erro inesperado: " + e.getMessage());
            }
        } while (opcao != 0);

        scanner.close(); // Fecha o scanner
    }
}

