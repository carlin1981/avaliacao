package modelo;

import java.util.ArrayList;
import java.util.List;

public class GerenciadorContatos {
    private List<Contato> contatos;
    private List<Long> idsDisponiveis; // Lista para IDs disponíveis
    private Long proximoId; // ID sequencial para novos contatos

    public GerenciadorContatos() {
        contatos = new ArrayList<>();
        idsDisponiveis = new ArrayList<>(); // Inicializa a lista de IDs disponíveis
        proximoId = 1L; // Começa a contagem a partir de 1
    }

    public void adicionarContato(Contato contato) {
        // Se houver IDs disponíveis, reutiliza um deles
        if (!idsDisponiveis.isEmpty()) {
            Long idReutilizado = idsDisponiveis.remove(idsDisponiveis.size() - 1); // Pega o último ID disponível
            contato.setId(idReutilizado);
        } else {
            contato.setId(proximoId);
            proximoId++; // Incrementa para o próximo ID
        }
        contatos.add(contato); // Adiciona o contato à lista
    }

    public void removerContato(Long id) {
        // Remove o contato se existir
        boolean removido = contatos.removeIf(contato -> contato.getId().equals(id));
        if (removido) {
            idsDisponiveis.add(id); // Adiciona o ID à lista de IDs disponíveis
            System.out.println("Contato removido com sucesso!"); // Mensagem de confirmação
        } else {
            System.out.println("Contato não encontrado para remoção."); // Mensagem se não encontrado
        }
    }

    public Contato pesquisarContatoPorId(Long id) {
        for (Contato contato : contatos) {
            if (contato.getId().equals(id)) {
                return contato; // Retorna o contato se encontrado
            }
        }
        return null; // Retorna null se não encontrar
    }

    public List<Contato> getContatos() {
        return contatos; // Retorna a lista de contatos
    }
}